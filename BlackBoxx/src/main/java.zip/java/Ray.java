import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.geometry.Point2D;

import java.util.List;

public class Ray {
    public ConstantValues.direction goingTo;
    double x;
    double y;
    double endX=0;
    double endY=0;
    int rowIndex;
    int colIndex;
    Line line;
    Pane parentpane;

    public Ray(ConstantValues.direction goingTo, double x, double y, Pane pane){
        parentpane = pane;
        this.goingTo = goingTo;
        this.x = x;
        this.y = y;
        goToStartHex();
    }

    public void goToStartHex(){
        Point2D targetPoint = new Point2D(x, y); // Example coordinates
        Hexagon hex = findNearestHexagon(targetPoint);
        //System.out.println(hex.centreX + "  " + hex.centreY);
        createLine();
        calculateEndPoint();
        createRay();
    }

    public void createRay(){
        //createLine();
        //calculateEndPoint();
        while(isThereNextHex()){
            createLine();
            calculateEndPoint();
            if(isThereNextHex()){
                Hexagon hextocheck = ConstantValues.hexList.get(rowIndex).get(colIndex);
                if(hextocheck.hasBorderingAtom) {
                    if (hextocheck.atomPlacement == ConstantValues.atomPlacement.UPRIGHT) {
                        if (goingTo == ConstantValues.direction.S_WEST) {
                            createLine();
                            System.out.println("hit");
                            break;
                        }
                        else if (goingTo == ConstantValues.direction.S_EAST) {
                            createLine();
                            goingTo = ConstantValues.direction.EAST;
                            createRay();
                        }
                        else if (goingTo == ConstantValues.direction.WEST) {
                            createLine();
                            goingTo = ConstantValues.direction.N_WEST;
                            createRay();
                        }
                    } else if (hextocheck.atomPlacement == ConstantValues.atomPlacement.UPLEFT) {
                        if (goingTo == ConstantValues.direction.S_EAST) {
                            createLine();
                            System.out.println("hit");
                            break;
                        }
                        else if (goingTo == ConstantValues.direction.EAST) {
                            createLine();
                            goingTo = ConstantValues.direction.N_EAST;
                            createRay();
                        }
                        else if (goingTo == ConstantValues.direction.S_WEST) {
                            createLine();
                            goingTo = ConstantValues.direction.WEST;
                            createRay();
                        }
                    } else if (hextocheck.atomPlacement == ConstantValues.atomPlacement.LEFT) {
                        if (goingTo == ConstantValues.direction.EAST) {
                            createLine();
                            System.out.println("hit");
                            break;
                        }
                        else if (goingTo == ConstantValues.direction.N_EAST) {
                            createLine();
                            goingTo = ConstantValues.direction.N_WEST;
                            createRay();
                        }
                        else if (goingTo == ConstantValues.direction.S_EAST) {
                            createLine();
                            goingTo = ConstantValues.direction.S_WEST;
                            createRay();
                        }
                    }else if (hextocheck.atomPlacement == ConstantValues.atomPlacement.DOWNLEFT) {
                        if (goingTo == ConstantValues.direction.N_EAST) {
                            createLine();
                            System.out.println("hit");
                            break;
                        }
                        else if (goingTo == ConstantValues.direction.EAST) {
                            createLine();
                            goingTo = ConstantValues.direction.S_EAST;
                            createRay();
                        }
                        else if (goingTo == ConstantValues.direction.N_WEST) {
                            createLine();
                            goingTo = ConstantValues.direction.WEST;
                            createRay();
                        }
                    } else if (hextocheck.atomPlacement == ConstantValues.atomPlacement.DOWNRIGHT) {
                        if (goingTo == ConstantValues.direction.N_WEST) {
                            createLine();
                            System.out.println("hit");
                            break;
                        }
                        else if (goingTo == ConstantValues.direction.WEST) {
                            createLine();
                            goingTo = ConstantValues.direction.S_WEST;
                            createRay();
                        }
                        else if (goingTo == ConstantValues.direction.N_EAST) {
                            createLine();
                            goingTo = ConstantValues.direction.EAST;
                            createRay();
                        }
                    }else if (hextocheck.atomPlacement == ConstantValues.atomPlacement.RIGHT) {
                        if (goingTo == ConstantValues.direction.WEST) {
                            createLine();
                            System.out.println("hit");
                            break;
                        }
                        else if (goingTo == ConstantValues.direction.S_WEST) {
                            createLine();
                            goingTo = ConstantValues.direction.S_EAST;
                            createRay();
                        }
                        else if (goingTo == ConstantValues.direction.N_WEST) {
                            createLine();
                            goingTo = ConstantValues.direction.N_EAST;
                            createRay();
                        }
                    }
                }
            }else{
                return;
            }

        }
    }

    public Hexagon findNearestHexagon(Point2D point) {
        Hexagon nearestHexagon = null;
        double minDistance = Double.MAX_VALUE;

        for(int row = 0; row < ConstantValues.hexList.size(); row++) {
            for (int col = 0; col < ConstantValues.hexList.get(row).size(); col++) {
                Hexagon hexagon = ConstantValues.hexList.get(row).get(col);
                double distance = calculateDistance(point, hexagon.centreX, hexagon.centreY);
                if (distance < minDistance) {
                    minDistance = distance;
                    nearestHexagon = hexagon;
                    rowIndex = row;
                    colIndex = col;
                }
            }
        }
        nearestHexagon.setFill(Color.RED);
        return nearestHexagon;
    } //works

    private double calculateDistance(Point2D point, double x, double y) {
        double dx = point.getX() - x;
        double dy = point.getY() - y;
        return Math.sqrt(dx * dx + dy * dy);
    }

    private void calculateEndPoint() {
        //System.out.println(rowIndex + "    " + colIndex);
        switch (goingTo) {
            case EAST:
                colIndex += 1;
                break;
            case WEST:
                colIndex -= 1;
                break;
            case S_EAST: //done
                if(rowIndex>=4) {
                    rowIndex += 1;
                }else{
                    colIndex += 1;
                    rowIndex += 1;
                }
                break;
            case N_EAST: // done
                if(rowIndex<=4) {
                    rowIndex -= 1;
                }else{
                    colIndex += 1;
                    rowIndex -= 1;
                }

                break;
            case N_WEST: //done
                if(rowIndex<=4) {
                    rowIndex -= 1;
                    colIndex -= 1;
                }else{
                    rowIndex -= 1;
                }
                break;
            case S_WEST://done
                if(rowIndex>=4) {
                    rowIndex += 1;
                    colIndex -= 1;
                }else{
                    rowIndex += 1;
                }
                break;
            default:
                break;
        }
    }

    private void createLine() {
        if (isThereNextHex()) {
            line = new Line(x, y, ConstantValues.hexList.get(rowIndex).get(colIndex).centreX, ConstantValues.hexList.get(rowIndex).get(colIndex).centreY);
            line.setStrokeWidth(1); // Adjust the thickness as needed
            line.setStroke(Color.WHITE); // Set the color to blue
            parentpane.getChildren().add(line);
            x = ConstantValues.hexList.get(rowIndex).get(colIndex).centreX;
            y = ConstantValues.hexList.get(rowIndex).get(colIndex).centreY;
        }else{
            return;
        }
    }

    private boolean isThereNextHex() {
        if (rowIndex < 0 || rowIndex >= ConstantValues.hexList.size()) {
            System.out.println("Out of bounds: row index");
            return false;
        }
        List<Hexagon> row = ConstantValues.hexList.get(rowIndex);
        if (colIndex < 0 || colIndex >= row.size()) {
            System.out.println("Out of bounds: column index");
            return false;
        }
        return true;
    }



}
